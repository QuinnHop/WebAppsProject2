export default Vue.component('joke-footer',{
	template: `<footer class="muted" style="text-align:center">
		   &copy; 2018 Ace Coder
		   </footer>`
});