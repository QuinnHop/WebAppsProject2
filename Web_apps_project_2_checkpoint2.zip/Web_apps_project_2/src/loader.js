import {init} from "./main.js"
window.onload = init;
